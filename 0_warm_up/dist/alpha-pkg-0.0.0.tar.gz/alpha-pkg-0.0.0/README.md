What happens when you run this command?
```
$ python setup.py sdist
```